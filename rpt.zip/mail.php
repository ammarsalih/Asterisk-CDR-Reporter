<?php
$to= $_POST['Address'];
$subject= 'Trixbox CDR report';
$message=$_POST['msg'];
$headers='Reports@My.Trixbox.com';
$result=mail($to, $subject, $message, $headers);

if (!$result){
 die('error: unable to send e-mail');
 }

else echo'Message sent !';
?>

