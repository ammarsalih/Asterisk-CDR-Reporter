<?php

//below are TrixBox Defaults

define (HOST, "localhost");
define (USER, "asteriskuser");
define (PASS, "amp109");
define (DBNAME, "asteriskcdrdb");

// I included PostgreSQL commands incase someone wants to test
//define ("PORT", "3306");
//define ("DB_TYPE", "mysql"); // mysql or postgres
//pg_connect("host=localhost port=5432 dbname=test user=username password=password");
//In the case of PostgreSQL, you have already selected the database in your pg_connect() function, so there is no function to select the database.
//pg_query(STRING);
//pg_fetch_array(RESULT);

?>


<html dir="ltr">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>New Page 1</title>
<style>
<!--
 table.MsoNormalTable
	{mso-style-parent:"";
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	}
 p.MsoNormal
	{mso-style-parent:"";
	margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:0in;
	line-height:115%;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	}
-->
</style>
</head>

<body>

<table class="MsoNormalTable" border="0" cellpadding="0" width="100%" style="width: 100.0%; color:#000080; font-family:Arial">
	<tr>
		<td width="467" valign="top" style="width: 350.2pt; padding: .75pt">
		<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">
		<b><span style="font-size: 12.0pt; font-family: Arial,sans-serif">&nbsp;</span></b></p>
		<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">
		<font color="#008000" size="3">
		<span style="font-family: Arial">Call 
		Details Record (usage summary view)</span></font></td>
		<td valign="top" style="padding: .75pt">&nbsp;</td>
		<?php 
		
	$Prefix= $_POST['Destination']; 
	$Sorc= $_POST['Source']; 
		$Dyte1= $_POST['St_Y'] . '-' . $_POST['St_M'] . '-' . $_POST['St_D'] . ' ' . $_POST['St_H'] . ':' . $_POST['St_Min'] . ':' . '00';
		$Dyte2= $_POST['En_Y'] . '-' . $_POST['En_M'] . '-' . $_POST['En_D'] . ' ' . $_POST['En_H'] . ':' . $_POST['En_Min'] . ':' . '00';

		
		echo('For usage peroid from '.$Dyte1.' to '.$Dyte2); ?> 
	</tr>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	
</table>

<table width="100%" style="border:3px solid #4F81BD; font-family: Arial; font-size: 8pt; color: #666699; border-collapse: collapse; padding-left:4px; padding-right:4px; padding-top:1px; padding-bottom:1px; " bgcolor="#FFFFFF" border="0" cellpadding="0">
	
	 <tr>
		<td bgcolor="#4F81BD" align="left" width="128">
		<font size="2" color="#FFFFFF"><b>Code</b></font></td>
		<td bgcolor="#4F81BD" align="left" width="91">
		<font size="2" color="#FFFFFF"><b>Attempts</b></font></td>
		<td bgcolor="#4F81BD" align="left" width="68">
		<font size="2" color="#FFFFFF"><b>Calls</b></font></td>
		<td bgcolor="#4F81BD" align="left"><font size="2" color="#FFFFFF"><b>Total Duration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
		</b>(Minutes)</font></td>
		<td bgcolor="#4F81BD" align="left" width="32">
		<font size="2" color="#FFFFFF"><b>ASR </b>(%)</font></td>
		<td bgcolor="#4F81BD" align="left" width="77">
		<font size="2" color="#FFFFFF"><b>ACD&nbsp;&nbsp;&nbsp; </b>(Minutes)</font></td>
		<td bgcolor="#4F81BD" align="left" width="93">
		<font size="2" color="#FFFFFF"><b>
		Total 
		charge&nbsp;&nbsp;&nbsp; </b>(AUD)</font><b><font face="Arial" color="#FFFFFF" size="2">&nbsp;&nbsp; </font></b></td>
		<td bgcolor="#4F81BD" align="left" width="89">&nbsp;<font size="2" color="#FFFFFF"><b>Revenue&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </b>
		(AUD)</font></td>
	</tr>

	<?php

  // Connect to the database server
  
  $dbcnx = @mysql_connect(HOST, USER, PASS);
  if (!$dbcnx) {
    die( '<p>Unable to connect to the ' .
         'database server at this time.</p>' );
  }

  
  if (! @mysql_select_db(DBNAME)) {
    die( '<p>Unable to locate the asteriskcdrdb' .
         'database at this time.</p>' );
  }

?>
<blockquote>
<?php

    $result = @mysql_query("SELECT * FROM cdr where calldate >= '$Dyte1' AND calldate <= '$Dyte2' ");
    if (!$result) {
    die('<p>Error performing query: ' . mysql_error() .
        '</p>');
  }

 
   $cunt=0;
   $TDur=0;
   $ACD=0;
   $ASR=0;
   $attempt=0;
   $Pr_len = strlen($Prefix);
   $Src_len = strlen($Sorc);
  while ( $row = mysql_fetch_array($result) ) {
if (!strncmp ($Prefix, $row['dst'] , $Pr_len ) && !strncmp ($Sorc, $row['src'] , $Src_len))
    {
    
    if($attempt < 20){ $last20Records[$attempt]=$row ;}
    
    if($row['disposition'] == "ANSWERED" ){
    $cunt++;
    $TDur=$TDur + $row['billsec'] ;}
    
  // $mints=FLOOR($row['billsec']/60); $rmid=($row['billsec'])%60;
  //  echo('<tr>' . '<p>' . '<td>'  . $cunt . '</td>'  . '<td>' . $row['src']  . '</td>'  . '<td>' .  $row['dst']  . '</td>'  . '<td>' .  date('Y-n-j   ,  g:i A',strtotime($row['calldate'])-25200)  . '</td>' . '<td>' .  $mints .':'. $rmid . '</td>'  . '<td>' . ceil($row['billsec'] / 60) . '</td>' . '</p>' . '</tr>');
   
    $attempt++;
   
  }
}
if($cunt > 0) $ACD=ROUND($TDur/$cunt/60,2);
if($attempt > 0) $ASR=ROUND($cunt/$attempt*100,2);
echo('<tr>' . '<p>' . '<td>'  . $Prefix . '</td>'  . '<td>' . $attempt  . '</td>'  . '<td>' .  $cunt  . '</td>'  . '<td>' . Round($TDur/60,0)  . '</td>' . '<td>' .  $ASR . '</td>'  . '<td>' . $ACD . '</td>' . '</p>' . '</tr>');
$Message =  ' Prefix:' .  $Prefix . ' attempts:' .$attempt . ' Successful Calls:' . $cunt . ' Total Duration:' . Round($TDur/60,0) . ' ASR:' . $ASR . ' ACD:' . $ACD;

?>
		
	
	
</table>

<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">&nbsp;</p>
<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">&nbsp;</p>
<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">
<font size="3" color="#008000"><span style="font-family: Arial">First 20 Records</span></font></p>

<table width="100%" style="border:3px solid #4F81BD; font-family: Arial; font-size: 8pt; color: #666699; border-collapse: collapse; padding-left:4px; padding-right:4px; padding-top:1px; padding-bottom:1px; " bgcolor="#FFFFFF" border="0" cellpadding="0" id="table1">
	
	 <tr>
		<td bgcolor="#4F81BD" align="left" width="43"><b>
		<font face="Arial" color="#FFFFFF" size="2">No.</font></b></td>
		<td bgcolor="#4F81BD" align="left" width="115"><b>
		<font face="Arial" color="#FFFFFF" size="2">Caller ID</font></b></td>
		<td bgcolor="#4F81BD" align="left"><font size="2" color="#FFFFFF"><b>
		Called Number</b></font></td>
		<td bgcolor="#4F81BD" align="left" width="92">
		<font size="2" color="#FFFFFF"><b>Date </b></font></td>
		<td bgcolor="#4F81BD" align="left" width="86">
		<font size="2" color="#FFFFFF"><b>Disposition</b></font></td>
		<td bgcolor="#4F81BD" align="left" width="107"><b>
		<font face="Arial" color="#FFFFFF" size="2">Duration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Minutes 
		: Sec)</font></b></td>
		<td bgcolor="#4F81BD" align="left" width="120"><b>
		<font face="Arial" color="#FFFFFF" size="2">Rounded Duration (Minutes)</font></b></td>
	</tr>

	
<?php

 for($a=0;$a<20 && $a<$attempt;$a++){
 
 $mints=FLOOR($last20Records[$a]['billsec']/60); $rmid=($last20Records[$a]['billsec'])%60;
 echo('<tr>' . '<p>' . '<td>'  . $a . '</td>'  . '<td>' .  $last20Records[$a]['src']  . '</td>'  . '<td>' .   $last20Records[$a]['dst']  . '</td>'  . '<td>' .  date('Y-n-j   ,  g:i A',strtotime($last20Records[$a]['calldate']))  . '</td>' . '<td>' .  $last20Records[$a]['disposition'] . '</td>' . '<td>' .  $mints .':'. $rmid . '</td>'  . '<td>' . ceil($last20Records[$a]['billsec'] / 60) . '</td>' . '</p>' . '</tr>');
 
  }
	
?>	
</table>

<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">&nbsp;</p>
<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">&nbsp;</p>
<form method="POST" action="mail.php">
	<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">
	<font color="#008000" size="3"><span style="font-family: Arial">I would like 
	to send report copy to my email address </span></font>&nbsp;<input type="text" name="Address" size="25"><font size="1" color="#808080"> 
	e.g.&nbsp; MyName@MyDomain.com</font></p>
	<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">&nbsp;</p>
	<p class="MsoNormal" style="line-height: normal; margin-bottom: .0001pt">
	<input type="submit" value="Send" name="B1"></p>
	<input type="hidden" name="msg" value="<?=$Message?>">
</form>

</body>

</html>